package jugador;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Juego.Juego;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Djugador extends JPanel {

	
	private JTextField tf_nombre;
	private JTextField tf_apellidos;
	private JTextField tf_genero;
	private JTextField tf_pais;
	private JTextField tf_edad;
	
	private login log;
	
	private Juego game;
	private jugador player;
	private Vprincipal principal;
	public JTextField tf_score;
	private Djugador referencia;
	

	
	public Djugador(jugador jugador, Vprincipal p,Juego juego) {
		this.player = jugador;
		this.game=juego;
		this.referencia=this;
		
		//actualizar datos de jugador;
		setBounds(100, 100, 839, 640);
		setLayout(null);
		
		JLabel lbl_logo = new JLabel("");
		lbl_logo.setBounds(83, 43, 70, 67);
		add(lbl_logo);
		
		JLabel lbl_nombre = new JLabel("Nombre");
		lbl_nombre.setBounds(220, 43, 77, 21);
		add(lbl_nombre);
		
		JLabel lbl_apellido = new JLabel("Apellidos");
		lbl_apellido.setBounds(220, 75, 77, 21);
		add(lbl_apellido);
		
		JLabel lbl_genero = new JLabel("Genero");
		lbl_genero.setBounds(220, 107, 77, 21);
		add(lbl_genero);
		
		JLabel lbl_pais = new JLabel("Pais");
		lbl_pais.setBounds(220, 139, 77, 21);
		add(lbl_pais);
		
		JLabel lbl_edad = new JLabel("Edad");
		lbl_edad.setBounds(220, 171, 77, 21);
		add(lbl_edad);
		
		JLabel lbl_score = new JLabel("Score");
		lbl_score.setBounds(220, 215, 77, 21);
		add(lbl_score);
		
		tf_nombre = new JTextField();
		tf_nombre.setBounds(295, 43, 155, 21);
		add(tf_nombre);
		tf_nombre.setColumns(10);
		
		tf_apellidos = new JTextField();
		tf_apellidos.setColumns(10);
		tf_apellidos.setBounds(295, 75, 155, 21);
		add(tf_apellidos);
		
		tf_genero = new JTextField();
		tf_genero.setColumns(10);
		tf_genero.setBounds(295, 107, 155, 21);
		add(tf_genero);
		 
		tf_pais = new JTextField();
		tf_pais.setColumns(10);
		tf_pais.setBounds(295, 139, 155, 21);
		add(tf_pais);
		
		tf_edad = new JTextField();
		tf_edad.setColumns(10);
		tf_edad.setBounds(295, 171, 155, 21);
		add(tf_edad);
		
		tf_score = new JTextField();
		tf_score.setColumns(10);
		tf_score.setBounds(295, 215, 155, 21);
		
		add(tf_score);
		
		tf_score.setEnabled(false);
		
		JButton btnActualizar = new JButton("Actualizar");
		btnActualizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
								player = new jugador();
				String nombre = tf_nombre.getText();
				String apellido = tf_apellidos.getText();
				int edad = (Integer.parseInt(tf_edad.getText()));
				String pais = tf_pais.getText();
				String genero=tf_genero.getText();
				
				
				player.setNombre(nombre);
				player.setApellidos(apellido);
				player.setEdad(edad);
				player.setPais(pais);
				player.setGenero(genero);
				game.setJugador(player);
				referencia.setJugador(player);
				
				
			}
		});
		btnActualizar.setBounds(301, 305, 89, 23);
		add(btnActualizar);
		setJugador(jugador);
		
	}
	public void setJugador (jugador jugador){
		this.player=jugador;
		tf_nombre.setText(jugador.getNombre());
		tf_edad.setText(String.valueOf(jugador.getEdad()));
		tf_apellidos.setText(jugador.getApellidos());
		tf_pais.setText(jugador.getPais());
		tf_genero.setText(jugador.getGenerotxt());
		tf_score.setText(String.valueOf(jugador.getScore()));
		
	}
	
}
