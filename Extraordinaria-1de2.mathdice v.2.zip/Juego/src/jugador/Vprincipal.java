package jugador;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Juego.Juego;

import java.awt.CardLayout;

public class Vprincipal extends JFrame {

	private JPanel cardLayoutPane;

	private Juego game;
	private Djugador perfil;
	
	
	//a�adimos el objeto jugador
	private jugador player;
	private boolean tocajuego=true;
	
	//login
	private login Login;
	
	private static final String V1="v1";
	private static final String V2="v2";
	private JMenuBar menuBar;
	private JMenu mnNewMenu;
	private JMenuItem mntmJuego;
	private JMenuItem mntmPerfil;
	


	
	
	
	public Vprincipal(login Login,jugador player) {
		
		this.Login=Login;
		this.player=player;
		tocajuego=false;
		
		
		
		
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 945, 641);
		
		menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		mnNewMenu = new JMenu("New menu");
		menuBar.add(mnNewMenu);
		mntmJuego = new JMenuItem("Juego");
		mnNewMenu.add(mntmJuego);
		mntmJuego.setEnabled(false);
		mntmJuego.addActionListener(new ActionListener() {
			

			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				
				game.setVisible(true);
				perfil.setVisible(false);
				mntmJuego.setEnabled(false);
				mntmPerfil.setEnabled(true);
				
			}
		});
		
		
		
		mntmPerfil = new JMenuItem("Perfil");
		mnNewMenu.add(mntmPerfil);
		mntmPerfil.addActionListener(new ActionListener() {
			

			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				perfil.setVisible(true);
				game.setVisible(false);
				mntmJuego.setEnabled(true);
				mntmPerfil.setEnabled(false);
				
			}
		});
		
		
		
		
		
		cardLayoutPane = new JPanel();
		cardLayoutPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(cardLayoutPane);
		cardLayoutPane.setLayout(new CardLayout(0, 0));
		
		
		game = new Juego(Login,this,player);
		cardLayoutPane.add(game, V1);
		
		perfil = new Djugador(player, this,game);
		cardLayoutPane.add(perfil, V2);
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
