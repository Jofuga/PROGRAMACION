package principal;

import java.awt.EventQueue;

import Juego.Juego;
import jugador.Djugador;
import jugador.jugador;
import jugador.login;

public class principal {
	
	public static void main(String[] args) {
		
		EventQueue.invokeLater(new Runnable(){
			public void run(){
				login Login=new login();
				Login.setVisible(true);
				
			}
			
		});
		
		

	}

}
